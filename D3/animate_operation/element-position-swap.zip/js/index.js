'use strict';

// variables
var $greenBox = $('#green'),
    $blueBox = $('#blue'),
    animation = 'flip',
    duration = 1100,
    effect = 'easeInOutExpo';

// functions
var disableButton = function disableButton(state) {
  return $('#swap').attr('disabled', state);
},
    getBoxPosition = function getBoxPosition() {
  return $greenBox.css('left') === '0px' ? moveBoxes('50%', '0px') : moveBoxes('0px', '50%');
},
    moveBoxes = function moveBoxes(green, blue) {
  disableButton(true);
  $greenBox.addClass(animation).animate({ left: green }, duration, effect, function () {
    $greenBox.removeClass(animation);
  });
  $blueBox.addClass(animation).animate({ left: blue }, duration, effect, function () {
    disableButton(false);
    $blueBox.removeClass(animation);
  });
};